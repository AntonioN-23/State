import React from 'react';
import { View, Text, StatusBar, StyleSheet } from 'react-native';

import useACSystem      from './hooks/useACSystem';
import StatusCard       from './components/StatusCard';
import ControlPanel     from './components/ControlPanel';
import TransitionLog    from './components/TransitionLog';

export default function App() {
  const {
    ui,
    logs,
    powerToggle,
    activateMode,
    adjustTarget,
    toggleAuto,
  } = useACSystem();

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />

      <View style={styles.header}>
        <Text style={styles.brand}>INVERTER  AC</Text>
        <Text style={styles.subtitle}>Sistema Automatizado · Patrón State</Text>
      </View>

      <StatusCard ui={ui} />

      <ControlPanel
        ui={ui}
        onPower={powerToggle}
        onMode={activateMode}
        onAdjust={adjustTarget}
        onToggleAuto={toggleAuto}
      />

      <TransitionLog logs={logs} />
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0d1117',
    paddingTop: 48,
    paddingHorizontal: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 18,
  },
  brand: {
    fontSize: 26,
    fontWeight: '900',
    color: '#eceff1',
    letterSpacing: 6,
  },
  subtitle: {
    fontSize: 10,
    color: '#546e7a',
    letterSpacing: 2,
    marginTop: 3,
  },
});