import { useState, useEffect, useRef } from 'react';
import ACContext from '../patterns/ACContext';

export default function useACSystem() {
  const [logs, setLogs] = useState([]);
  const [ui, setUi] = useState({
    stateName  : 'Apagado',
    stateIcon  : '⏻',
    stateColor : '#455a64',
    stateDesc  : 'Sistema desactivado',
    fanSpeed   : 'off',
    compressor : false,
    roomTemp   : 28,
    targetTemp : 22,
    autoMode   : true,
    isOff      : true,
    isError    : false,
  });

  const acRef = useRef(null);

  const addLog = (msg) => {
    const time = new Date().toLocaleTimeString('es-MX', {
      hour: '2-digit', minute: '2-digit', second: '2-digit',
    });
    setLogs((prev) => [`[${time}]  ${msg}`, ...prev].slice(0, 30));
  };

  useEffect(() => {
    acRef.current = new ACContext(setUi, addLog);
    setUi(acRef.current.snapshot());
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const ac = acRef.current;
      if (!ac || ac._state.name === 'Apagado' || ac._state.name === 'Error') return;

      let drift = 0;
      if (ac._state.compressor) {
        const factor = ac._state.name === 'Turbo' ? 1.0 : 0.5;
        drift = ac.roomTemp > ac.targetTemp ? -factor : factor;
      } else {
        drift = Math.random() > 0.5 ? 0.1 : -0.1;
      }

      ac.roomTemp = Math.round((ac.roomTemp + drift) * 10) / 10;
      ac.handle();
      setUi({ ...ac.snapshot() });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const powerToggle = () => acRef.current?.powerToggle();

  const activateMode = (mode) => acRef.current?.activateMode(mode);

  const adjustTarget = (delta) => {
    const ac = acRef.current;
    if (!ac || ac._state.name === 'Apagado' || ac._state.name === 'Error') return;
    ac.targetTemp = Math.min(30, Math.max(16, ac.targetTemp + delta));
    ac.handle();
    setUi({ ...ac.snapshot() });
  };

  const toggleAuto = (val) => {
    const ac = acRef.current;
    if (!ac) return;
    ac.autoMode = val;
    setUi({ ...ac.snapshot(), autoMode: val });
  };

  return { ui, logs, powerToggle, activateMode, adjustTarget, toggleAuto };
}