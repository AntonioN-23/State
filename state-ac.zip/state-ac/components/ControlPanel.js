import React from 'react';
import { View, Text, TouchableOpacity, Switch, ScrollView, StyleSheet } from 'react-native';

const MODES = [
  { key: 'eco',        label: 'Eco',          icon: '🌿', color: '#1b4332' },
  { key: 'turbo',      label: 'Turbo',         icon: '⚡', color: '#4a3800' },
  { key: 'fanOnly',    label: 'Ventilación',   icon: '🌀', color: '#263238' },
  { key: 'dehumidify', label: 'Deshumidificar',icon: '💧', color: '#003544' },
  { key: 'night',      label: 'Noche',         icon: '🌛', color: '#2e1f5e' },
];

export default function ControlPanel({ ui, onPower, onMode, onAdjust, onToggleAuto }) {
  const blocked = ui.isOff || ui.isError;

  return (
    <View style={styles.container}>

      {/* Control de temperatura */}
      <View style={styles.row}>
        <TouchableOpacity style={styles.tempBtn} onPress={() => onAdjust(-1)} disabled={blocked}>
          <Text style={[styles.tempBtnText, blocked && styles.disabled]}>−</Text>
        </TouchableOpacity>
        <View style={styles.labelBox}>
          <Text style={styles.rowLabel}>TEMPERATURA OBJETIVO</Text>
          <Text style={styles.targetVal}>{ui.targetTemp}°C</Text>
        </View>
        <TouchableOpacity style={styles.tempBtn} onPress={() => onAdjust(1)} disabled={blocked}>
          <Text style={[styles.tempBtnText, blocked && styles.disabled]}>+</Text>
        </TouchableOpacity>
      </View>

      {/* Modo automático */}
      <View style={styles.row}>
        <Text style={styles.rowLabel}>MODO AUTOMÁTICO</Text>
        <Switch
          value={ui.autoMode}
          onValueChange={onToggleAuto}
          trackColor={{ false: '#37474f', true: '#26a69a' }}
          thumbColor={ui.autoMode ? '#80cbc4' : '#78909c'}
        />
      </View>

      {/* Botón de encendido */}
      <TouchableOpacity
        style={[styles.powerBtn, { backgroundColor: ui.isOff ? '#26a69a' : '#ef5350' }]}
        onPress={onPower}
      >
        <Text style={styles.powerBtnText}>
          {ui.isError ? '🔄  Reset (Apagar)' : ui.isOff ? '⏻  Encender' : '⏼  Apagar'}
        </Text>
      </TouchableOpacity>

      {/* Selector de modos */}
      <Text style={styles.modesLabel}>MODOS</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.modesScroll}>
        {MODES.map((m) => {
          const active = ui.stateName === MODES.find(x => x.key === m.key)?.label ||
                         ui.stateName === m.label;
          return (
            <TouchableOpacity
              key={m.key}
              style={[
                styles.modeBtn,
                { backgroundColor: m.color },
                active && styles.modeBtnActive,
                blocked && styles.disabledBtn,
              ]}
              onPress={() => onMode(m.key)}
              disabled={blocked}
            >
              <Text style={styles.modeIcon}>{m.icon}</Text>
              <Text style={styles.modeLabel}>{m.label}</Text>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { gap: 10, marginBottom: 14 },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: '#141d26',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 18,
  },
  rowLabel: { fontSize: 10, color: '#546e7a', letterSpacing: 1.5 },

  tempBtn: {
    width: 42, height: 42,
    backgroundColor: '#1e2d3d',
    borderRadius: 21,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tempBtnText: { fontSize: 24, color: '#80cbc4', fontWeight: '700' },
  labelBox: { alignItems: 'center' },
  targetVal: { fontSize: 24, fontWeight: '700', color: '#eceff1', marginTop: 2 },

  powerBtn: {
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
  },
  powerBtnText: { fontSize: 14, fontWeight: '700', color: '#fff', letterSpacing: 1 },

  modesLabel: { fontSize: 10, color: '#546e7a', letterSpacing: 1.5, paddingLeft: 4 },
  modesScroll: { flexGrow: 0 },

  modeBtn: {
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    paddingVertical: 10,
    paddingHorizontal: 16,
    marginRight: 8,
    borderWidth: 1,
    borderColor: 'transparent',
    minWidth: 80,
  },
  modeBtnActive: { borderColor: '#eceff1' },
  modeIcon:  { fontSize: 22 },
  modeLabel: { fontSize: 10, color: '#cfd8dc', marginTop: 4, letterSpacing: 0.5 },

  disabled:    { color: '#37474f' },
  disabledBtn: { opacity: 0.3 },
});