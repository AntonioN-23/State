import React, { useEffect, useRef } from 'react';
import { View, Text, Animated, StyleSheet } from 'react-native';

const FAN_LABELS = { off: '—', low: '◎', med: '◉ ◉', high: '◉ ◉ ◉' };

export default function StatusCard({ ui }) {
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (ui.compressor) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.06, duration: 900, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1,    duration: 900, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.stopAnimation();
      pulseAnim.setValue(1);
    }
  }, [ui.compressor]);

  return (
    <Animated.View
      style={[
        styles.card,
        { borderColor: ui.stateColor, transform: [{ scale: pulseAnim }] },
      ]}
    >
      <Text style={styles.icon}>{ui.stateIcon}</Text>
      <Text style={[styles.stateName, { color: ui.stateColor }]}>{ui.stateName}</Text>
      <Text style={styles.stateDesc}>{ui.stateDesc}</Text>

      {/* Temperaturas */}
      <View style={styles.tempRow}>
        <View style={styles.tempBox}>
          <Text style={styles.tempLabel}>SALA</Text>
          <Text style={[styles.tempValue, { color: ui.stateColor }]}>{ui.roomTemp}°C</Text>
        </View>
        <View style={styles.divider} />
        <View style={styles.tempBox}>
          <Text style={styles.tempLabel}>OBJETIVO</Text>
          <Text style={styles.tempValue}>{ui.targetTemp}°C</Text>
        </View>
      </View>

      {/* Badges */}
      <View style={styles.badgeRow}>
        <View style={styles.badge}>
          <Text style={styles.badgeLabel}>VENTILADOR</Text>
          <Text style={styles.badgeVal}>{FAN_LABELS[ui.fanSpeed]}</Text>
        </View>
        <View style={[styles.badge, ui.compressor && { borderColor: ui.stateColor }]}>
          <Text style={styles.badgeLabel}>COMPRESOR</Text>
          <Text style={[styles.badgeVal, { color: ui.compressor ? ui.stateColor : '#546e7a' }]}>
            {ui.compressor ? 'ON' : 'OFF'}
          </Text>
        </View>
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1.5,
    borderRadius: 20,
    padding: 20,
    alignItems: 'center',
    backgroundColor: '#141d26',
    marginBottom: 14,
  },
  icon:      { fontSize: 46, marginBottom: 6 },
  stateName: { fontSize: 22, fontWeight: '800', letterSpacing: 2 },
  stateDesc: { fontSize: 12, color: '#78909c', marginTop: 4, marginBottom: 16 },

  tempRow:  { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  tempBox:  { flex: 1, alignItems: 'center' },
  tempLabel:{ fontSize: 10, color: '#546e7a', letterSpacing: 2, marginBottom: 2 },
  tempValue:{ fontSize: 30, fontWeight: '700', color: '#eceff1' },
  divider:  { width: 1, height: 40, backgroundColor: '#263238' },

  badgeRow: { flexDirection: 'row', gap: 12 },
  badge: {
    borderWidth: 1,
    borderColor: '#263238',
    borderRadius: 10,
    paddingVertical: 6,
    paddingHorizontal: 18,
    alignItems: 'center',
  },
  badgeLabel: { fontSize: 9, color: '#546e7a', letterSpacing: 1.5 },
  badgeVal:   { fontSize: 15, fontWeight: '700', color: '#eceff1', marginTop: 2 },
});