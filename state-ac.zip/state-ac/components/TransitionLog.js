import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';

export default function TransitionLog({ logs }) {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>▸ REGISTRO DE TRANSICIONES</Text>
      <ScrollView style={styles.scroll} nestedScrollEnabled>
        {logs.length === 0 ? (
          <Text style={styles.empty}>Sin eventos aún…</Text>
        ) : (
          logs.map((entry, i) => (
            <Text key={i} style={[styles.entry, i === 0 && styles.entryNew]}>
              {entry}
            </Text>
          ))
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a1018',
    borderRadius: 14,
    padding: 14,
    marginBottom: 20,
  },
  title:    { fontSize: 10, color: '#26a69a', letterSpacing: 2, marginBottom: 8 },
  scroll:   { flex: 1 },
  empty:    { color: '#37474f', fontSize: 12, fontStyle: 'italic' },
  entry:    { fontSize: 11, color: '#546e7a', paddingVertical: 2, fontFamily: 'monospace' },
  entryNew: { color: '#80cbc4' },
});