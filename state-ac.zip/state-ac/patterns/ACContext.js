import {
  OffState, StandbyState, EcoState,
  TurboState, FanOnlyState, DehumidifyState, NightModeState, ErrorState,
} from './ACStates';

export default class ACContext {

  constructor(setState, addLog) {
    this._state     = new OffState();
    this.setState   = setState;
    this.addLog     = addLog;
    this.roomTemp   = 28;
    this.targetTemp = 22;
    this.autoMode   = true;
  }

  transitionTo(newState) {
    const prevName = this._state.name;
    this._state.onExit(this);
    this._state = newState;
    this._state.onEnter(this);
    this.addLog(`${prevName} → ${newState.name}`);
    this.setState({ ...this.snapshot() });
  }

  handle() {
    if (this.autoMode) {
      this._state.handle(this);
    }
  }

  powerToggle() {
    if (this._state instanceof OffState) {
      this.transitionTo(new StandbyState());
    } else {
      this.transitionTo(new OffState());
    }
  }

  activateMode(ModeName) {
    if (this._state instanceof OffState) return;
    const map = {
      eco        : new EcoState(),
      turbo      : new TurboState(),
      fanOnly    : new FanOnlyState(),
      dehumidify : new DehumidifyState(),
      night      : new NightModeState(),
    };
    if (map[ModeName]) this.transitionTo(map[ModeName]);
  }

  snapshot() {
    return {
      stateName   : this._state.name,
      stateIcon   : this._state.icon,
      stateColor  : this._state.color,
      stateDesc   : this._state.description,
      fanSpeed    : this._state.fanSpeed,
      compressor  : this._state.compressor,
      roomTemp    : this.roomTemp,
      targetTemp  : this.targetTemp,
      autoMode    : this.autoMode,
      isOff       : this._state instanceof OffState,
      isError     : this._state instanceof ErrorState,
    };
  }
}