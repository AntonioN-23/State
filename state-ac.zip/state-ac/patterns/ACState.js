export default class ACState {
  constructor(name, icon, color, description, fanSpeed, compressor) {
    this.name = name;
    this.icon = icon;
    this.color = color;
    this.description = description;
    this.fanSpeed = fanSpeed;     // 'off' | 'low' | 'med' | 'high'
    this.compressor = compressor; 
  }

  onEnter(context) {}

  onExit(context) {}

  handle(context) {
    throw new Error(`handle() no implementado en: ${this.name}`);
  }
}