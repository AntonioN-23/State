import ACState from './ACState';

// ── 1. APAGADO ────────────────────────────────────────────────
export class OffState extends ACState {
  constructor() {
    super('Apagado', '⏻', '#455a64', 'Sistema desactivado', 'off', false);
  }
  handle(context) {
  }
}

// ── 2. STANDBY ────────────────────────────────────────────────
export class StandbyState extends ACState {
  constructor() {
    super('Standby', '🌙', '#5c6bc0', 'En espera — monitoreando temperatura', 'low', false);
  }
  handle(context) {
    if (context.roomTemp > context.targetTemp + 2) {
      context.transitionTo(new CoolingState());
    } else if (context.roomTemp < context.targetTemp - 2) {
      context.transitionTo(new HeatingState());
    }
  }
}

// ── 3. ENFRIANDO ──────────────────────────────────────────────
export class CoolingState extends ACState {
  constructor() {
    super('Enfriando', '❄️', '#29b6f6', 'Compresor activo — modo frío', 'high', true);
  }
  handle(context) {
    if (context.roomTemp <= context.targetTemp) {
      context.transitionTo(new MaintainingState());
    }
    if (context.roomTemp < context.targetTemp - 5) {
      context.transitionTo(new ErrorState('Sobreenfriamiento detectado'));
    }
  }
}

// ── 4. CALENTANDO ─────────────────────────────────────────────
export class HeatingState extends ACState {
  constructor() {
    super('Calentando', '🔆', '#ef5350', 'Modo calor — inverter activo', 'med', true);
  }
  handle(context) {
    if (context.roomTemp >= context.targetTemp) {
      context.transitionTo(new MaintainingState());
    }
  }
}

// ── 5. MANTENIENDO ────────────────────────────────────────────
export class MaintainingState extends ACState {
  constructor() {
    super('Manteniendo', '✅', '#66bb6a', 'Temperatura óptima alcanzada', 'low', false);
  }
  handle(context) {
    if (context.roomTemp > context.targetTemp + 1.5) {
      context.transitionTo(new CoolingState());
    } else if (context.roomTemp < context.targetTemp - 1.5) {
      context.transitionTo(new HeatingState());
    }
  }
}

// ── 6. ECO ────────────────────────────────────────────────────
export class EcoState extends ACState {
  constructor() {
    super('Eco', '🌿', '#26a69a', 'Ahorro energético — inverter optimizado', 'low', true);
  }
  handle(context) {
    if (context.roomTemp > context.targetTemp + 3) {
      context.transitionTo(new CoolingState());
    } else if (context.roomTemp < context.targetTemp - 3) {
      context.transitionTo(new HeatingState());
    }
  }
}

// ── 7. TURBO ──────────────────────────────────────────────────
export class TurboState extends ACState {
  constructor() {
    super('Turbo', '⚡', '#ffd600', 'Potencia máxima — enfriamiento/calor rápido', 'high', true);
  }
  handle(context) {
    const diff = Math.abs(context.roomTemp - context.targetTemp);
    if (diff <= 1.5) {
      context.transitionTo(new MaintainingState());
    }
    if (context.roomTemp < context.targetTemp - 6 || context.roomTemp > context.targetTemp + 10) {
      context.transitionTo(new ErrorState('Límite térmico en Turbo'));
    }
  }
}

// ── 8. VENTILACIÓN ────────────────────────────────────────────
export class FanOnlyState extends ACState {
  constructor() {
    super('Ventilación', '🌀', '#78909c', 'Solo ventilador — sin compresor', 'med', false);
  }
  handle(context) {
  }
}

// ── 9. DESHUMIDIFICACIÓN ──────────────────────────────────────
export class DehumidifyState extends ACState {
  constructor() {
    super('Deshumidificar', '💧', '#4dd0e1', 'Extrayendo humedad del ambiente', 'low', true);
  }
  handle(context) {
    if (context.roomTemp < context.targetTemp - 2) {
      context.transitionTo(new MaintainingState());
    }
  }
}

// ── 10. MODO NOCHE ────────────────────────────────────────────
export class NightModeState extends ACState {
  constructor() {
    super('Modo Noche', '🌛', '#9575cd', 'Silencioso — ajuste gradual nocturno', 'low', false);
  }
  handle(context) {
    if (context.roomTemp > context.targetTemp + 2.5) {
      context.transitionTo(new CoolingState());
    } else if (context.roomTemp < context.targetTemp - 2.5) {
      context.transitionTo(new HeatingState());
    }
  }
}

// ── 11. ERROR / PROTECCIÓN ────────────────────────────────────
export class ErrorState extends ACState {
  constructor(reason = 'Falla desconocida') {
    super('Error', '⚠️', '#ff5722', `Protección activada: ${reason}`, 'off', false);
    this.reason = reason;
  }
  handle(context) {
  }
}